console.log('And we\'re off');

var $form;
$form = $(#wrong-syntax);